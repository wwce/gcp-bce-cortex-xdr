import base64
import os
from google.cloud import pubsub_v1
import requests
import secrets
import string
import hashlib
from datetime import datetime, timezone

XDR_KEY = os.environ.get('XDR_KEY')
XDR_KEY_ID = os.environ.get('XDR_KEY_ID')
BASE_URL = "https://api-illicium-industrial.xdr.us.paloaltonetworks.com/public_api/v1/"
INSTANCE_PER_PAGE = 100

def generate_headers():
    # Generate a 64 bytes random string
    nonce = "".join([secrets.choice(string.ascii_letters + string.digits) for _ in range(64)])
    # Get the current timestamp as milliseconds.
    timestamp = int(datetime.now(timezone.utc).timestamp()) * 1000
    # Generate the auth key:
    auth_key = "%s%s%s" % (XDR_KEY, nonce, timestamp)
    # Convert to bytes object
    auth_key = auth_key.encode("utf-8")
    # Calculate sha256:
    api_key_hash = hashlib.sha256(auth_key).hexdigest()
    # Generate HTTP call headers
    headers = {
        "x-xdr-timestamp": str(timestamp),
        "x-xdr-nonce": nonce,
        "x-xdr-auth-id": str(XDR_KEY_ID),
        "Authorization": api_key_hash
    }
    return headers


def get_xdr_endpoints():
    method = 'endpoints/get_endpoint'  # careful, get_endpoints provides different response...
    endpoints = []
    parameters = {'request_data': {}}
    url = BASE_URL + method
    response = requests.post(url=url, headers=generate_headers(), json=parameters)
    reply = response.json()['reply']
    num_pages = reply['total_count'] // INSTANCE_PER_PAGE
    for endpoint in reply['endpoints']:
        endpoints.append(endpoint['endpoint_id'])
    cur_page = 1
    while cur_page <= num_pages:
        parameters = {'request_data': {'search_from': cur_page * INSTANCE_PER_PAGE,
                                       'search_to': (cur_page+1) * INSTANCE_PER_PAGE}
                      }
        response = requests.post(url=url, headers=generate_headers(), json=parameters)
        reply = response.json()['reply']
        num_pages = reply['total_count'] // INSTANCE_PER_PAGE
        for endpoint in reply['endpoints']:
            endpoints.append(endpoint['endpoint_id'])
    return endpoints, reply

def hello_pubsub(event, context):
    """Triggered from a message on a Cloud Pub/Sub topic.
    Args:
         event (dict): Event payload.
         context (google.cloud.functions.Context): Metadata for the event.
    """
    publisher = pubsub_v1.PublisherClient()
    project_id = 'function-receiver'
    topic_id = "id-mapping"
    topic_path = publisher.topic_path(project_id, topic_id)

    endpoints, reply = get_xdr_endpoints()
    
    for endpoint in endpoints:
        message = endpoint
        # call the topics/functions
        try:
            response = publisher.publish(topic_path, message.encode())
            print(response)
        except Exception as e:
            print(e)
