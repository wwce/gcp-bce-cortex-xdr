import os
import json
import base64
from datetime import datetime, timezone
from google.cloud import spanner
from google.oauth2 import service_account
import secrets
import string
import hashlib
import requests
import time

TIMEOUT = int(os.environ.get('TIMEOUT'))
RETRY = int(os.environ.get('RETRY'))
#CRED_JSON = os.environ.get('CRED_JSON')


def insert_id_mapping_wrapper(xdr_agent_id, bce_device_id):
    def insert_id_mapping(transaction):
        command = 'INSERT INTO xdr_bce (xdr_id, bce_id) VALUES ("{}", "{}")'.format(xdr_agent_id, bce_device_id)
        print(command)
        transaction.execute_update(command)
    return insert_id_mapping


def hello_pubsub(event, context):
    target_id = base64.b64decode(event['data']).decode('utf-8')
    api = "https://api-illicium-industrial.xdr.us.paloaltonetworks.com/public_api/v1/"
    api_key_id = int(os.environ.get('XDR_KEY_ID'))
    api_key = os.environ.get('XDR_KEY')

    uri = "scripts/run_snippet_code_script/"
    with open('get_file_script.py', 'r') as f:
        code_snippet = f.read()
    parameters = {
        "request_data": {
            "filters": [
                {
                    "field": "endpoint_id_list",
                    "operator": "in",
                    "value": [target_id]
                }
            ],
            "snippet_code": code_snippet
        }
    }
    response = make_api_call(api, uri, parameters, api_key_id, api_key)
    time.sleep(TIMEOUT)
    print(response.text)
    action_id = None
    retry_count = RETRY
    while action_id is None and retry_count > 0:
        reply = json.loads(response.text).get('reply')
        if reply:
            action_id = reply.get('action_id')
        time.sleep(TIMEOUT)
        retry_count -= 1
    if action_id is None:
        error_message = "Fail to get the accounts.json for {}".format(target_id)
        print(error_message)
        return error_message

    # get script results
    uri = "scripts/get_script_execution_results"
    parameters = {"request_data": {"action_id": action_id}}

    response = make_api_call(api, uri, parameters, api_key_id, api_key)
    reply = response.json().get('reply')
    print(reply)
    print('=' * 30)
    ids = reply['results'][0].get('standard_output')
    # select existing keys to determine to use INSERT or UPDATE
    #json_account_info = json.load(open('cred.json'))
    #credentials = service_account.Credentials.from_service_account_info(json_account_info)
    client = spanner.Client(project=os.environ.get('PROJECT_ID'))

    # Get Instance
    spanner_instance = client.instance('xdr-bce-db')

    # Get Database
    db = spanner_instance.database('xdr_bce_data')

    # Get existing bce_id to avoid duplicate insert
    with db.snapshot() as snapshot:
        results = snapshot.execute_sql('SELECT bce_id FROM xdr_bce')
    bce_ids = set()
    for result in results:
        bce_ids.add(result[0])
    if ids is not None and ids != '':
        for id in ids.split('\n'):
            if id not in bce_ids:
                db.run_in_transaction(
                    insert_id_mapping_wrapper(TARGET_ID, id))
            else:
                print('The bce id is already insert!')


def make_api_call(api, uri, parameters, api_key_id, api_key):
    # Generate a 64 bytes random string
    nonce = "".join([secrets.choice(string.ascii_letters + string.digits) for _ in range(64)])
    # Get the current timestamp as milliseconds.
    timestamp = int(datetime.now(timezone.utc).timestamp()) * 1000
    # Generate the auth key:
    auth_key = "%s%s%s" % (api_key, nonce, timestamp)
    # Convert to bytes object
    auth_key = auth_key.encode("utf-8")
    # Calculate sha256:
    api_key_hash = hashlib.sha256(auth_key).hexdigest()
    # Generate HTTP call headers
    headers = {
        "x-xdr-timestamp": str(timestamp),
        "x-xdr-nonce": nonce,
        "x-xdr-auth-id": str(api_key_id),
        "Authorization": api_key_hash
    }

    url = api + uri
    print(url)
    res = requests.post(url=url, headers=headers, json=parameters)
    return res


if __name__ == "__main__":
    hello_pubsub(None, None)

