import json
import sys
import os


def get_id_by_path(path):
    data = json.load(open(path))
    for key in data:
        print(data[key]['device']['resourceId'])


if sys.platform == 'linux' or sys.platform == 'linux2':
    base = '/home'
    postfix = '.config/google/Endpoint Verification'
    for user in os.listdir(base):
        path = '{}/{}/{}'.format(base, user, postfix)
        if os.path.exists(path):
            get_id_by_path(path)
elif sys.platform == 'darwin':
    base = '/Users'
    postfix = 'Library/Application Support/Google/Endpoint Verification/accounts.json'
    for user in os.listdir(base):
        path = '{}/{}/{}'.format(base, user, postfix)
        if os.path.exists(path):
            get_id_by_path(path)
elif sys.platform == 'win32':
    base = r'C:\Users'
    postfix = r'AppData\Local\Google\Endpoint Verification\accounts.json'
    for user in os.listdir(base):
        path = r'{}\{}\{}'.format(base, user, postfix)
        if os.path.exists(path):
            get_id_by_path(path)
