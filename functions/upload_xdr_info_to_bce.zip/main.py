import os
import json
import google_auth_httplib2
from google.oauth2.service_account import Credentials
from collections import defaultdict
from httplib2 import Http
from google.oauth2 import service_account
from google.cloud import spanner


# Google api global variable
SCOPES = [
    'https://www.googleapis.com/auth/cloud-identity.devices'
]
EMAIL = os.environ.get('EMAIL')
CUSTOMER_ID = os.environ.get('CUSTOMER_ID')
PARTNER_ID = os.environ.get('PARTNER_ID')
CRED_JSON = os.environ.get('CRED_JSON')


def run_db_command_wrapper(command):
    def run_db_command(transaction):
        print(command)
        transaction.execute_update(command)
    return run_db_command


def hello_pubsub(event, context):
    # Get Device Users - requires domain-wide delegation
    json_obj = json.loads(CRED_JSON)
    cred = Credentials.from_service_account_info(json_obj, scopes=SCOPES, subject=EMAIL)
    http = google_auth_httplib2.AuthorizedHttp(cred, http=Http())
    base_url = 'https://cloudidentity.googleapis.com/v1/devices/-/deviceUsers'
    response = http.request(base_url, 'GET')
    data = json.loads(response[1])
    deviceUsers = data['deviceUsers']
    device_deviceUsers_mapping = defaultdict(list)
    for deviceUser in deviceUsers:
        deviceName = deviceUser['name'].split('/')[-1]
        device_deviceUsers_mapping[deviceName].append(deviceUser['name'])
    # Get health score from Google Spanner
    client = spanner.Client(project=os.environ.get('PROJECT_ID'))
    spanner_instance = client.instance('xdr-bce-db')
    db = spanner_instance.database('xdr_bce_data')
    command = 'SELECT xdr_bce.bce_id, xdr_info.health_score, xdr_info.endpoint_status, xdr_info.is_isolated ' \
              'FROM xdr_bce, xdr_info where xdr_info.xdr_id = xdr_bce.xdr_id'
    with db.snapshot() as snapshot:
        results = snapshot.execute_sql(command)
    updated_target = []
    for bce_id, health_score, endpoint_status, is_isolated in results:
        for deviceUser in device_deviceUsers_mapping[bce_id]:
            info_dict = {'health_score': health_score, 'endpoint_status': endpoint_status, 'is_isolated': is_isolated}
            updated_target.append((deviceUser, info_dict))
    print('updated_target ...')
    print(updated_target)
    print('=' * 30)

    for deviceUser, info_dict in updated_target:
        base_url = 'https://cloudidentity.googleapis.com/v1/{}/clientStates/{}'.format(deviceUser, PARTNER_ID)
        # base_url = 'https://cloudidentity.googleapis.com/v1/{}/clientStates/{}-{}'.format(deviceUser, CUSTOMER_ID, PARTNER_ID)
        print(base_url)
        body = {
            'customId': CUSTOMER_ID,
            'healthScore': info_dict['health_score'],
            'managed': 'MANAGED' if info_dict['endpoint_status'] == 'CONNECTED' else 'UNMANAGED',
            'complianceState': 'COMPLIANT' if info_dict['is_isolated'] == 'AGENT_UNISOLATED' else 'NON_COMPLIANT'
        }
        response = http.request(base_url, method='PATCH', body=json.dumps(body))
        print(response)

    # check the result
    base_url = 'https://cloudidentity.googleapis.com/v1/devices/-/deviceUsers/-/clientStates'
    response = http.request(base_url, 'GET')
    data = json.loads(response[1])
    clientStates = data['clientStates']
    print('=' * 30)
    for clientState in clientStates:
        if clientState['name'].split('/')[-1] == '{}-{}'.format(CUSTOMER_ID, PARTNER_ID):
            print(clientState)


if __name__ == '__main__':
    hello_pubsub(None, None)

