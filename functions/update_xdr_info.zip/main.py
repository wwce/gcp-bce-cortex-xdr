import base64
from datetime import datetime, timezone
from collections import defaultdict
from google.cloud import spanner
from google.oauth2 import service_account
import secrets
import string
import hashlib
import requests
import os
import time
import json

BASE_URL = "https://api-illicium-industrial.xdr.us.paloaltonetworks.com/public_api/v1/"

STATUS_MAPPING = {
    0: 'VERY_POOR',
    1: 'POOR',
    2: 'NEUTRAL',
    3: 'GOOD',
    4: 'VERY_GOOD'
}

COLUMNS = ['health_score', 'is_isolated', 'endpoint_status']

INSTANCE_PER_PAGE = 100

XDR_KEY = os.environ.get('XDR_KEY')
XDR_KEY_ID = os.environ.get('XDR_KEY_ID')


def hello_pubsub(event, context):
    """Triggered from a message on a Cloud Pub/Sub topic via cron job.
    Args:
         event (dict): Event payload.
         context (google.cloud.functions.Context): Metadata for the event.
    """

    endpoints, reply = get_xdr_endpoints()
    endpoints_info = get_endpoints_info(reply)
    alerts = get_alerts_for_endpoints(endpoints)
    health_scores = generate_health_score(endpoints, alerts)
    # append health scores to endpoints_info
    for key in health_scores:
        endpoints_info[key]['health_score'] = health_scores[key]
    update_db(endpoints_info)
    return alerts, health_scores, reply, endpoints_info


def get_endpoints_info(endpoint_reply):
    endpoints_info = endpoint_reply['endpoints']
    result = {}
    target_cols = ['is_isolated', 'endpoint_status']
    for endpoint_info in endpoints_info:
        result[endpoint_info['endpoint_id']] = {}
        for col in target_cols:
            result[endpoint_info['endpoint_id']][col] = endpoint_info[col]
    return result


def get_xdr_endpoints():
    method = 'endpoints/get_endpoint'  # careful, get_endpoints provides different response...
    endpoints = []
    parameters = {'request_data': {}}
    url = BASE_URL + method
    response = requests.post(url=url, headers=generate_headers(), json=parameters)
    reply = response.json()['reply']
    num_pages = reply['total_count'] // INSTANCE_PER_PAGE
    for endpoint in reply['endpoints']:
        endpoints.append(endpoint['endpoint_id'])
    cur_page = 1
    while cur_page <= num_pages:
        parameters = {'request_data': {'search_from': cur_page * INSTANCE_PER_PAGE,
                                       'search_to': (cur_page+1) * INSTANCE_PER_PAGE}
                      }
        response = requests.post(url=url, headers=generate_headers(), json=parameters)
        reply = response.json()['reply']
        num_pages = reply['total_count'] // INSTANCE_PER_PAGE
        for endpoint in reply['endpoints']:
            endpoints.append(endpoint['endpoint_id'])
    return endpoints, reply


def get_alerts_for_endpoints(endpoints):
    """

    Args:
        endpoints: A list of endpoint_id

    Returns:
        result: A default dict that mapping from endpoint id to a list of alerts

    """
    endpoints_set = set(endpoints)
    method = 'alerts/get_alerts_multi_events'
    parameters = {'request_data':
                      {
                          'filters': [
                            {
                                'field': 'creation_time',
                                'operator': 'gte',
                                'value': int((time.time() - 3600 * 24 * 7) * 1000)
                            }
                          ]
                      }
    }
    url = BASE_URL + method
    response = requests.post(url=url, headers=generate_headers(), json=parameters)
    reply = response.json()['reply']
    alerts = reply['alerts']
    num_pages = reply['total_count'] // INSTANCE_PER_PAGE
    result = defaultdict(list)
    for alert in alerts:
        if alert['endpoint_id'] in endpoints_set and (alert['severity'] == 'medium' or alert['severity'] == 'high'):
            result[alert['endpoint_id']].append(alert)
    cur_page = 1
    while cur_page <= num_pages:
        parameters = {'request_data': {'search_from': cur_page * INSTANCE_PER_PAGE,
                                       'search_to': (cur_page+1) * INSTANCE_PER_PAGE,
                                       'filters': [
                                           {
                                               'field': 'creation_time',
                                               'operator': 'gte',
                                               'value': int((time.time() - 3600 * 24 * 7) * 1000)
                                           }
                                       ]
                                       }

                      }
        response = requests.post(url=url, headers=generate_headers(), json=parameters)
        reply = response.json()['reply']
        alerts = reply['alerts']
        for alert in alerts:
            if alert['endpoint_id'] in endpoints_set and (alert['severity'] == 'medium' or alert['severity'] == 'high'):
                result[alert['endpoint_id']].append(alert)
        cur_page += 1

    return result


def generate_health_score(endpoints, alerts):
    """

    Args:
        endpoints: a list of endpoint_id
        alerts: the endpoints and alerts mapping (endpoint_id -> list)

    Returns:
        result: the mapping from the endpoint_id to the status

    """
    result = {}
    for endpoint in endpoints:
        # No alert the default is very good
        score = 4
        # If there are multiple alerts, I use the most severe alert as the status.
        for alert in alerts[endpoint]:
            if alert['severity'] == 'high':
                # If the alert is severe but blocked, I regard it as POOR
                if alert['action'] == 'BLOCKED':
                    score = min(score, 1)
                # If the alert is severe and not blocked, I regard it as VERY_POOR
                else:
                    score = min(score, 0)
            elif alert['severity'] == 'medium':
                # If the alert is medium but blocked, I regard it as NEUTRAL
                if alert['action'] == 'BLOCKED':
                    score = min(score, 2)
                # If the alert is medium and not blocked, I regard it as POOR
                else:
                    score = min(score, 1)
        result[endpoint] = STATUS_MAPPING[score]
    return result


def insert_health_score(transaction, id, health_score):
    command = 'INSERT INTO health_score (xdr_agent_id, health_score) VALUES ("{}", "{}")'.format(id, health_score)
    transaction.execute_update(command)
    print(command)


def run_db_command_wrapper(command):
    def run_db_command(transaction):
        print(command)
        transaction.execute_update(command)
    return run_db_command


def update_db(endpoints_info):
    # select existing keys to determine to use INSERT or UPDATE
    #json_account_info = json.load(open('cred.json'))
    #credentials = service_account.Credentials.from_service_account_info(json_account_info)
    client = spanner.Client(project=os.environ.get('PROJECT_ID'))
    # Get Instance
    spanner_instance = client.instance('xdr-bce-db')
    # Get Database
    db = spanner_instance.database('xdr_bce_data')
    # Select Table
    with db.snapshot() as snapshot:
        results = snapshot.execute_sql('SELECT xdr_id FROM xdr_info')
    xdr_ids = set()
    for result in results:
        xdr_ids.add(result[0])
    for id, info_dict in endpoints_info.items():
        if id not in xdr_ids:
            command = 'INSERT INTO xdr_info (xdr_id, health_score, is_isolated, endpoint_status) VALUES ("{}", "{}", "{}", "{}")'.\
                format(id, info_dict['health_score'], info_dict['is_isolated'], info_dict['endpoint_status'])
            db.run_in_transaction(run_db_command_wrapper(command))
        else:
            command = 'UPDATE xdr_info SET xdr_info.health_score="{}", xdr_info.is_isolated="{}", xdr_info.endpoint_status="{}" WHERE xdr_id="{}"'.\
                format(info_dict['health_score'], info_dict['is_isolated'], info_dict['endpoint_status'], id)
            db.run_in_transaction(run_db_command_wrapper(command))

def generate_headers():
    # Generate a 64 bytes random string
    nonce = "".join([secrets.choice(string.ascii_letters + string.digits) for _ in range(64)])
    # Get the current timestamp as milliseconds.
    timestamp = int(datetime.now(timezone.utc).timestamp()) * 1000
    # Generate the auth key:
    auth_key = "%s%s%s" % (XDR_KEY, nonce, timestamp)
    # Convert to bytes object
    auth_key = auth_key.encode("utf-8")
    # Calculate sha256:
    api_key_hash = hashlib.sha256(auth_key).hexdigest()
    # Generate HTTP call headers
    headers = {
        "x-xdr-timestamp": str(timestamp),
        "x-xdr-nonce": nonce,
        "x-xdr-auth-id": str(XDR_KEY_ID),
        "Authorization": api_key_hash
    }
    return headers


# This part is for testing
if __name__ == '__main__':
    alerts, health_scores, reply, endpoints_info = hello_pubsub(None, None)

